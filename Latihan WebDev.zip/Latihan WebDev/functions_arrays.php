<?php
// functions_arrays.php

// Fungsi untuk menyapa seorang siswa
function sapa($nama) {
    return "Halo, $nama!";
}

// Array dari nama-nama siswa
$siswa = ["Ryan", "Bubub", "Levin", "Fj", "Piang"];

// Melintasi array dan menyapa setiap siswa
foreach ($siswa as $siswa) {
    echo sapa($siswa) . "\n"; // Output sapaan
}
?>