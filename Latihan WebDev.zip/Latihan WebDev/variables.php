<?php
// Deklarasikan dan inisialisasi variabel
$name = "Alfian "; // Variabel string untuk nama Anda
$age = 18; // Variabel integer untuk umur Anda
$sex = "laki-laki"; // Variabel string untuk gender Anda (laki-laki/perempuan)
$gpa = 3.3; // Angka titik mengambang yang mewakili skor GPA
$isStudent = true; // Variabel boolean yang diatur ke true
$birthYear = 2006; // Variabel integer untuk tahun lahir Anda
$birthMonth = "February"; // Variabel string untuk bulan lahir Anda

//mencetak variabel untuk memeriksa nilainya
echo "Nama: $name\n";
echo "Umur: $age\n";
echo "Jenis Kelamin: $sex\n";
echo "GPA: $gpa\n";
echo "Apakah Siswa: " . ($isStudent ? 'Ya' : 'Tidak') . "\n";
echo "Tahun Lahir: $birthYear\n";
echo "Bulan Lahir: $birthMonth\n";
?>