<?php
// Mendefinisikan variabel umur
$age = 20; // bisa  mengubah nilai ini untuk menguji alur yang berbeda

// Memeriksa apakah orang tersebut dewasa atau tidak
if ($age >= 18) {
    echo "Anda adalah orang dewasa.";
} else {
    echo "Anda adalah orang muda.";
}
?>